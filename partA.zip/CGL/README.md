# CGL Library 
Designed to build simple graphics applications for 15-462 : Computer Graphics

The library provides basic vector operations, takes care of OpenGL context creation, window event handling, and an on-screen text display interface using freetype. The library is designed to provide a simple interface for building graphics applications and is used in 15-462 assignments.
