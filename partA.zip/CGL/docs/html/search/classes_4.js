var searchData=
[
  ['spectrum',['Spectrum',['../class_c_m_u462_1_1_spectrum.html',1,'CGL']]]
];
