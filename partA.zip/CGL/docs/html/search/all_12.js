var searchData=
[
  ['zero',['zero',['../class_c_m_u462_1_1_matrix3x3.html#a453beeb9cce4e6a40ae5328165e3c753',1,'CGL::Matrix3x3::zero()'],['../class_c_m_u462_1_1_matrix4x4.html#a30a749d68ec7e6958a9fc84e335be0c8',1,'CGL::Matrix4x4::zero()']]]
];
