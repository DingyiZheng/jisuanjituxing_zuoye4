var searchData=
[
  ['osdtext',['OSDText',['../class_c_m_u462_1_1_o_s_d_text.html',1,'CGL']]],
  ['osdtext',['OSDText',['../class_c_m_u462_1_1_o_s_d_text.html#a1f29bdf4a5b3fe64e113b1a3b8e1a53d',1,'CGL::OSDText']]]
];
