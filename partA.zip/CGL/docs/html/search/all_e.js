var searchData=
[
  ['scroll_5fevent',['scroll_event',['../class_c_m_u462_1_1_renderer.html#a8c08a5be2bcca581bf151a69566cb8fe',1,'CGL::Renderer']]],
  ['set_5fanchor',['set_anchor',['../class_c_m_u462_1_1_o_s_d_text.html#a3b8eca3d00b2e3d8b4ffefd2c954fb15',1,'CGL::OSDText']]],
  ['set_5fcolor',['set_color',['../class_c_m_u462_1_1_o_s_d_text.html#a5bd8361d49244bb3ce2d1f28d06b0b2f',1,'CGL::OSDText']]],
  ['set_5frenderer',['set_renderer',['../class_c_m_u462_1_1_viewer.html#a718e6c8bc9b6522e0eb08d1ad7cfb812',1,'CGL::Viewer']]],
  ['set_5fsize',['set_size',['../class_c_m_u462_1_1_o_s_d_text.html#ad7cfd0bd9f0781c5681af725164783e9',1,'CGL::OSDText']]],
  ['set_5ftext',['set_text',['../class_c_m_u462_1_1_o_s_d_text.html#acc04d475d3e9f1ad4013e7abcc8726a5',1,'CGL::OSDText']]],
  ['spectrum',['Spectrum',['../class_c_m_u462_1_1_spectrum.html#a843ed7c0ba50026b98d88996ba7edbea',1,'CGL::Spectrum::Spectrum(double r=0, double g=0, double b=0)'],['../class_c_m_u462_1_1_spectrum.html#af4c77c2988a300e670f8a77dc0ab4626',1,'CGL::Spectrum::Spectrum(const uint8_t *arr)']]],
  ['spectrum',['Spectrum',['../class_c_m_u462_1_1_spectrum.html',1,'CGL']]],
  ['start',['start',['../class_c_m_u462_1_1_timer.html#af1ce06f7092988480ee89f0cccf62a9a',1,'CGL::Timer::start()'],['../class_c_m_u462_1_1_viewer.html#afa69177f56fed243755762bb1dd09bf1',1,'CGL::Viewer::start()']]],
  ['stop',['stop',['../class_c_m_u462_1_1_timer.html#a367ad2569ce28e00aa0ecd4f9cc29767',1,'CGL::Timer']]]
];
