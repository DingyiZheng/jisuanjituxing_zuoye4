var searchData=
[
  ['b',['b',['../class_c_m_u462_1_1_color.html#a5ae56ddf662d80a6cfd423664d99d648',1,'CGL::Color::b()'],['../class_c_m_u462_1_1_spectrum.html#a2aaca7f6e0861698339001336543f045',1,'CGL::Spectrum::b()']]]
];
