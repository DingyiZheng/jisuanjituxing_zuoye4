var searchData=
[
  ['g',['g',['../class_c_m_u462_1_1_color.html#a4a3179778bc75342961e5b96a1b8b228',1,'CGL::Color::g()'],['../class_c_m_u462_1_1_spectrum.html#a735a15fc99d7e219cd91214b7ac499e8',1,'CGL::Spectrum::g()']]]
];
